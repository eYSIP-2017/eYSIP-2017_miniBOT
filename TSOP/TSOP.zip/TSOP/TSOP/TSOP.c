/*
 * Author List: Sakshi Gupta and Darshan M
 * Filename: newprogram.c
 * Functions: transform(),decode(),navigate() ,int main()
 * Global Variables: defined below
 *
 */
#define  F_CPU 14745600
#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>
#include "Motion_control.h"
/**********************Global Variables*****************/
#define RC5_GetStartBits(command) ((command & 0x3000) >> 12)
#define RC5_GetToggleBit(command) ((command & 0x800) >> 11)
#define RC5_GetAddressBits(command) ((command & 0x7C0) >> 6)
#define RC5_GetCommandBits(command) (command & 0x3F)
#define RC5_GetCommandAddressBits(command) (command & 0x7FF)
int counts_array[50];
volatile char i=0;
int flag=0;
int intcount=0;
uint8_t ccounter;
volatile uint16_t command;  
typedef enum
{
  start1,
  start0,
  mid1,
  mid0,
}
State;


typedef enum
{
  short_pulse,
  long_pulse
}
Pulse;

Pulse pulse;

State state = mid1;
void init_ports()
{
  DDRL=0x18;
  PORTL=0x18;
  DDRJ=0xff;
  PORTJ=0x00;
  DDRE = 0x00;
  PORTE=0x00;
}
//Function to initialize uart
void uart2_init(void)
{
  UCSR2B = 0x00; //disable while setting baud rate
  UCSR2A = 0x00;
  UCSR2C = 0x06;
  UBRR2L = 0x5F; //set baud rate lo
  UBRR2H = 0x00; //set baud rate hi
  UCSR2B = 0x98;
}

void timer3_init(void)
{
  TCCR3B = 0x00; //stop
  TCCR3A = 0x00;
  TCCR3C = 0x00;
  TCNT3H = 0x00; //Counter higher 8 bit value
  TCNT3L = 0x00; //Counter lower 8 bit value
  OCR3AH = 0x00; //Output compare Register (OCR)- Not used
  OCR3AL = 0x00; //Output compare Register (OCR)- Not used
  OCR3BH = 0x00; //Output compare Register (OCR)- Not used
  OCR3BL = 0x00; //Output compare Register (OCR)- Not used
  OCR3CH = 0x00; //Output compare Register (OCR)- Not used
  OCR3CL = 0x00; //Output compare Register (OCR)- Not used
  ICR3H  = 0x00; //Input Capture Register (ICR)- Not used
  ICR3L  = 0x00; //Input Capture Register (ICR)- Not used
}

void timer4_init(void)
{
  TCCR4B = 0x00; //stop
  TCNT4H = 0x00; //Counter higher 8 bit value
  TCNT4L = 0x00; //Counter lower 8 bit value
  OCR4AH = 0x00; //Output compare Register (OCR)- Not used
  OCR4AL = 0x00; //Output compare Register (OCR)- Not used
  OCR4BH = 0x00; //Output compare Register (OCR)- Not used
  OCR4BL = 0x00; //Output compare Register (OCR)- Not used
  OCR4CH = 0x00; //Output compare Register (OCR)- Not used
  OCR4CL = 0x00; //Output compare Register (OCR)- Not used
  ICR4H  = 0x00; //Input Capture Register (ICR)- Not used
  ICR4L  = 0x00; //Input Capture Register (ICR)- Not used
  TCCR4A = 0x00;
  TCCR4C = 0x00;
  }
  /****************************************************************
  * Function: Interrupt Service Routine
  * Input: none
  * Output: none
  * Logic: whenever interrupt0 occurs it executes this routine
  *        and after this it returns to the main function
  *****************************************************************/
ISR(INT7_vect)
{
  cli();
  counts_array[i]=TCNT4L;
  if (i==0)
  {
    TCCR3B = 0x05; //start Timer
  }
  TCNT4L = 0x00;
  i++;

}
//Function to initialize devices
void init_devices()
{
  cli();
  init_ports();
  EICRA=0x00;
  EICRB=0x40; // Any Level Change
  EIMSK=0x80;
  timer3_init();
  timer4_init();
  TIMSK3 = 0x00; //timer3 overflow interrupt disable
  TIMSK4 = 0x00; //timer4 overflow interrupt disable
  sei();
}
/*************************************************
 * Function Name: main
 * Input: None
 * Output: int to inform the caller that the program exited correctly or incorrectly (C code standard)
 * Logic: initializes the timer and different parameters
 * Example Call: Called automatically by the Operating System
 *
 ***********************************************/
int main(void)
{
  uart2_init();
  init_devices();
  motion_pin_config();
  uint8_t nav=0x0C;
  uint8_t toggle_save;
  TCCR4B = 0x05; //start Timer
  if (i>=0x18)
  {
	  TCCR3B = 0x00; //stop Timer
	  TCNT3H = 0x00; //reload counter high value
	  TCNT3L = 0x00;
	  transform();
	  decode();
	  uint8_t toggle = RC5_GetToggleBit(command); //Get Toggle Bit
	  toggle_save = toggle;
	  uint8_t address = RC5_GetAddressBits(command);//Get Address Bit
	  uint8_t cmdnum = RC5_GetCommandBits(command);//Get Command Bit
	  navigate(cmdnum);
	  UDR2=cmdnum;
	  command=0;
	  i=0;
  }
  while(1)
  {
     if (i>=0x18)
    {
      TCCR3B = 0x00; //stop Timer
      TCNT3H = 0x00; //reload counter high value
      TCNT3L = 0x00;
      transform();
      decode();
      uint8_t toggle = RC5_GetToggleBit(command); //Get Toggle Bit
	  if (toggle == toggle_save)					// To check multiple press of button
	  {
		 command=0;
		 i=0;
		 continue; 
	  }
	  else
	  toggle_save = toggle;
      uint8_t address = RC5_GetAddressBits(command);//Get Address Bit
      uint8_t cmdnum = RC5_GetCommandBits(command);//Get Command Bit
      navigate(cmdnum);
      UDR2=cmdnum;
      command=0;
      i=0;
    }
  }
}
/*************************************************
 * Function Name: transform
 * Input: None
 * Output:None
 * Logic: Checks the count values in the array and identify whether it is short pulse or long pulse
 * Example Call: Called in the main function
 *************************************************/
void transform(void)
{
  for (int j=1;j<=0x1C;j++)
  {
    if (counts_array[j]<0x0F)
      counts_array[j]=short_pulse;  //Assign 0 for short pulse
    else
      counts_array[j]=long_pulse;   //Assign 1 for long pulse
  }
}
/*************************************************
 * Function Name: decode
 * Input: None
 * Output: None
 * Logic: Decode all the 14 bits of protocol
 * Example Call: Called in the main function
 *************************************************/

void decode(void)
{
  int j=1;
  state = mid1;
  ccounter=14;
  ccounter--;  // 7
  command |= 1 << ccounter;
  ccounter--;  // 6
  do
  {
    pulse=counts_array[j];
    if (state==mid1 && pulse==short_pulse)
    {
      state=start1;
      command |= 1 << ccounter;
      ccounter--;
    }

    else if (state==mid0 && pulse==short_pulse )
    {
      state=start0;
      ccounter--;
    }
    else if (state==mid1 && pulse==long_pulse)
    {
      state=mid0;
      ccounter--;
    }

    else if (state==mid0 && pulse==long_pulse)
    {
      command |= 1 << ccounter;
      state=mid1;
      ccounter--;
    }
    else if (state==start1 && pulse==short_pulse)
    {
      state=mid1;
    }
    else if (state==start0 && pulse==short_pulse)
    {
      state=mid0;
    }
    j++;
  }
  while (ccounter>0);
}


/*****************************************
  Navigation of the Robot depending on key pressed in the TV remote
  Forward --> Key 2
  Backward --> Key 8
  Left --> Key 4
  Right --> Key 6
  Stop --> key MUTE
*******************************************/
void navigate(uint8_t nav) // Receives the value corresponding to the key pressed
{
  switch (nav)
  {
  case 0x02: 
    forward();
    break;
	
  case 0x08:
    backward(); 
    break;
  
  case 0x04:
    sharp_left();
    break;
  
  case 0x06:
    sharp_right();
    break;
  
  case 0x0C:
    stop();
    break;

  default:
    break;

  }

}
