/*
* 
* Team Id: 			eYRC#1085-WM
* Author List: 		Archie Mittal
* Filename: 		Motion_control.h
* Theme: 			Warehouse Managing Robot
* Functions: 		motion_pin_config(), sharp_right(), sharp_left(), forward(), backward(), stop()
* Global Variables:	NONE
*
*/

/*
* Function Name:	motion_pin_config 
* Input:			None
* Output:			Sets PA0-PA3 as output pins 
* Logic:			Output of the left motor is connected to PA0 and PA1 and output of right motor is connected to PA2 and PA3.
*					Thus by giving logic '1' to DDRA0-DDRA3 these pins are set as output pins.
* Example Call:		motion_pin_config();
*
*/
void motion_pin_config (void)
{ 
	DDRL=0x18;
	PORTL=0x18;
	DDRA = DDRA | 0x0F;
	PORTA = PORTA & 0xF0;
}

/*
* Function Name:	sharp_right
* Input:			None
* Output:			The bot moves in right direction from its position
* Logic:			Left wheel forward, Right wheel backward
* Example Call:		sharp_right();
*
*/
void sharp_right(void)
{
	PORTA=PORTA|0x0F;
	PORTA=PORTA&0xFA;
}

/*
* Function Name:	sharp_left
* Input:			None
* Output:			The bot moves in left direction from its position
* Logic:			Left wheel backward, Right wheel forward
* Example Call:		sharp_left();
*
*/
void sharp_left(void)
{
	PORTA=PORTA|0x0F;
	PORTA=PORTA&0xF5;	
}

/*
* Function Name:	forward
* Input:			None
* Output:			The bot moves in forward direction
* Logic:			both wheels forward
* Example Call:		forward();
*
*/
void forward(void)
{
	PORTA=PORTA|0x0F;
	PORTA=PORTA&0xF6;
}

/*
* Function Name:	backward
* Input:			None
* Output:			The bot moves in backward direction
* Logic:			Both wheels backward
* Example Call:		backward();
*
*/
void backward(void)
{
	PORTA=PORTA|0x0F;
	PORTA=PORTA&0xF9;	
}

/*
* Function Name:	stop
* Input:			None
* Output:			hard stop
* Logic:			Both wheels stop rotating
* Example Call:		stop();
*
*/
void stop(void)
{
	PORTA=PORTA&0xF0;	
}
